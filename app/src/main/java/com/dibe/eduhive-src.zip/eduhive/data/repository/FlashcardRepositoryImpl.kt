package com.dibe.eduhive.data.repository

import com.dibe.eduhive.data.local.entity.FlashcardEntity
import com.dibe.eduhive.data.source.ai.AIDataSource
import com.dibe.eduhive.data.source.ai.FlashcardGenerationState
import com.dibe.eduhive.data.source.local.FlashcardLocalDataSource
import com.dibe.eduhive.domain.model.Flashcard
import com.dibe.eduhive.domain.repository.FlashcardRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.UUID
import jakarta.inject.Inject


class FlashcardRepositoryImpl @Inject constructor(
    private val localDataSource: FlashcardLocalDataSource,
    private val aiDataSource: AIDataSource
) : FlashcardRepository {

    override suspend fun addFlashcards(flashcards: List<Flashcard>) {
        val entities = flashcards.map { FlashcardEntity.fromDomain(it) }
        localDataSource.insertAll(entities)
    }

    override suspend fun getFlashcardsForConcept(conceptId: String): List<Flashcard> {
        return localDataSource.getForConcept(conceptId).map { it.toDomain() }
    }

    override suspend fun getFlashcardById(flashcardId: String): Flashcard? {
        return localDataSource.getById(flashcardId)?.toDomain()
    }

    override suspend fun getDueFlashcards(maxBox: Int, limit: Int): List<Flashcard> {
        return localDataSource.getDue(maxBox).take(limit).map { it.toDomain() }
    }

    override suspend fun updateLeitnerBox(
        flashcardId: String,
        newBox: Int,
        lastSeenAt: Long,
        nextReviewAt: Long
    ) {
        localDataSource.updateLeitner(
            id = flashcardId,
            box = newBox.coerceIn(1, 5),
            time = lastSeenAt
        )
    }

    override suspend fun deleteFlashcard(flashcardId: String) {
        localDataSource.deleteAllForConcept(flashcardId)
    }

    /**
     * 🚀 STREAMING: Generate flashcards with real-time status updates.
     */
    override fun generateFlashcardsForConceptStreaming(
        conceptId: String,
        conceptName: String,
        conceptDescription: String?,
        count: Int
    ): Flow<FlashcardGenerationProgress> = flow {
        emit(FlashcardGenerationProgress.Loading)

        aiDataSource.generateFlashcardsStreaming(
            conceptName = conceptName,
            conceptDescription = conceptDescription ?: "",
            count = count
        ).collect { state ->
            when (state) {
                is FlashcardGenerationState.Loading -> {
                    emit(FlashcardGenerationProgress.Loading)
                }
                is FlashcardGenerationState.Success -> {
                    val flashcards = state.flashcards.map { generated ->
                        Flashcard(
                            id = UUID.randomUUID().toString(),
                            conceptId = conceptId,
                            front = generated.front,
                            back = generated.back,
                            currentBox = 1,
                            lastSeenAt = null,
                            nextReviewAt = System.currentTimeMillis()
                        )
                    }

                    // Save to database
                    addFlashcards(flashcards)

                    emit(FlashcardGenerationProgress.Success(flashcards))
                }
                is FlashcardGenerationState.Error -> {
                    emit(FlashcardGenerationProgress.Error(state.message))
                }
            }
        }
    }

    /**
     * Standard suspend function (delegates to streaming internally).
     */
    override suspend fun generateFlashcardsForConcept(
        conceptId: String,
        conceptName: String,
        conceptDescription: String?,
        count: Int
    ): List<Flashcard> {
        var result: List<Flashcard> = emptyList()

        generateFlashcardsForConceptStreaming(
            conceptId, conceptName, conceptDescription, count
        ).collect { progress ->
            when (progress) {
                is FlashcardGenerationProgress.Success -> {
                    result = progress.flashcards
                }
                is FlashcardGenerationProgress.Error -> {
                    // Return empty list on error
                }
                else -> { /* Ignore loading states */ }
            }
        }

        return result
    }
}

/**
 * Progress states for flashcard generation UI.
 */
sealed class FlashcardGenerationProgress {
    object Loading : FlashcardGenerationProgress()
    data class Success(val flashcards: List<Flashcard>) : FlashcardGenerationProgress()
    data class Error(val message: String) : FlashcardGenerationProgress()
}