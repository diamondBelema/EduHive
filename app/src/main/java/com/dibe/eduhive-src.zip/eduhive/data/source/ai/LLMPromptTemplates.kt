package com.dibe.eduhive.data.source.ai

/**
 * Centralized prompt templates for each LLM generation stage.
 *
 * Tuned for small on-device models (135M–1B parameters).
 * Key principles:
 *  - Be extremely explicit about output format — small models drift without it
 *  - Use short, imperative sentences — no nested clauses
 *  - Always show a concrete example — small models copy examples better than rules
 *  - Never ask for a range ("3 to 8") — always give a firm minimum
 */
object LLMPromptTemplates {

    /**
     * Concept extraction prompt for a single page/block of text.
     *
     * Design notes:
     * - "List exactly 5" is more reliable than "3 to 8" for small models
     * - The example block shows the exact format to copy
     * - Keeping the instruction block short leaves more token budget for the text
     */
    fun conceptExtraction(text: String, hiveContext: String = ""): String {
        val contextLine = if (hiveContext.isNotEmpty()) "Topic area: $hiveContext\n" else ""
        return """
List exactly 5 key educational concepts from the text below.
${contextLine}
Text:
$text

Format each concept exactly like this example:
CONCEPT: Photosynthesis
DESCRIPTION: The process by which plants convert sunlight into glucose using chlorophyll.

CONCEPT: [name]
DESCRIPTION: [one sentence explanation]

CONCEPT: [name]
DESCRIPTION: [one sentence explanation]

CONCEPT: [name]
DESCRIPTION: [one sentence explanation]

CONCEPT: [name]
DESCRIPTION: [one sentence explanation]

CONCEPT: [name]
DESCRIPTION: [one sentence explanation]
        """.trimIndent()
    }

    /**
     * Flashcard draft generation for a single concept.
     *
     * Design notes:
     * - Removed the "must end with ?" rule — small models often produce
     *   fill-in-the-blank or definition cards without a question mark,
     *   which are educationally valid. The validator no longer rejects these.
     * - Example shown first so the model has a pattern to copy immediately
     */
    fun flashcardDraft(conceptName: String, conceptDescription: String, count: Int): String {
        return """
Create $count flashcards about: $conceptName
Context: $conceptDescription

Example:
FRONT: What is the main function of mitochondria?
BACK: To produce ATP energy for the cell through cellular respiration.

Now create $count flashcards. Use this exact format:
FRONT: [question or prompt]
BACK: [concise answer, 1-2 sentences max]
        """.trimIndent()
    }

    /**
     * Batched flashcard generation for multiple concepts.
     */
    fun flashcardBatch(
        concepts: List<Pair<String, String>>,
        countPerConcept: Int
    ): String {
        val conceptsBlock = concepts.mapIndexed { index, (name, desc) ->
            "Concept ${index + 1}: $name — $desc"
        }.joinToString("\n")

        val total = concepts.size * countPerConcept
        return """
Create $total flashcards across these ${concepts.size} concepts:
$conceptsBlock

Tag each card with its concept number. Use this exact format:
CONCEPT: 1
FRONT: [question or prompt]
BACK: [concise answer]

CONCEPT: 2
FRONT: [question or prompt]
BACK: [concise answer]

Create $countPerConcept cards per concept. No duplicate questions.
        """.trimIndent()
    }

    /**
     * Refinement prompt for improving low-quality draft flashcards.
     */
    fun flashcardRefinement(draftFlashcards: List<GeneratedFlashcard>): String {
        val cardsBlock = draftFlashcards.joinToString("\n\n") { card ->
            "FRONT: ${card.front}\nBACK: ${card.back}"
        }
        return """
Rewrite these flashcards to be clearer and more specific.
Keep the same FRONT/BACK format. Keep the same number of cards.

$cardsBlock

Rewritten flashcards:
        """.trimIndent()
    }

    /**
     * Quiz question generation prompt.
     *
     * Design notes:
     * - Showing one complete example of each type prevents format drift
     * - Explicit QUESTION N header helps the parser split blocks correctly
     */
    fun quizGeneration(conceptName: String, conceptDescription: String, count: Int): String {
        return """
Create $count quiz questions about: $conceptName
Context: $conceptDescription

Use this exact format for MCQ:
QUESTION 1
TYPE: MCQ
TEXT: What is the primary function of X?
OPTION A: First option
OPTION B: Second option
OPTION C: Third option
OPTION D: Fourth option
CORRECT: A

Use this exact format for TRUE_FALSE:
QUESTION 2
TYPE: TRUE_FALSE
TEXT: X is responsible for Y.
OPTION A: True
OPTION B: False
CORRECT: A

Now create $count questions:
        """.trimIndent()
    }

    /**
     * Prompt mutation variants for retry logic.
     * Each attempt adds a short re-focusing instruction.
     */
    fun mutate(basePrompt: String, attempt: Int): String {
        val suffix = when (attempt) {
            0 -> ""
            1 -> "\nUse clear, specific language. No vague answers."
            2 -> "\nFocus on definitions, causes, and effects."
            else -> "\nBe precise. Use exact terminology from the text."
        }
        return basePrompt + suffix
    }
}