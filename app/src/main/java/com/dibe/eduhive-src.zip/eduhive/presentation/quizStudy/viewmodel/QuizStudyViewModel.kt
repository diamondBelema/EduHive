package com.dibe.eduhive.presentation.quizStudy.viewmodel

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dibe.eduhive.domain.model.Quiz
import com.dibe.eduhive.domain.model.QuizQuestion
import com.dibe.eduhive.domain.repository.ConceptRepository
import com.dibe.eduhive.domain.repository.QuizRepository
import com.dibe.eduhive.domain.usecase.concept.GetConceptsByHiveUseCase
import com.dibe.eduhive.domain.usecase.review.QuizQuestionResult
import com.dibe.eduhive.domain.usecase.review.SubmitQuizResultUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class QuizStudyViewModel @Inject constructor(
    private val getConceptsByHiveUseCase: GetConceptsByHiveUseCase,
    private val conceptRepository: ConceptRepository,
    private val quizRepository: QuizRepository,
    private val submitQuizResultUseCase: SubmitQuizResultUseCase,
    savedStateHandle: SavedStateHandle
) : ViewModel() {

    private val hiveId: String = checkNotNull(savedStateHandle["hiveId"])
    private val isAllHives: Boolean get() = hiveId == "ALL"

    private val _state = MutableStateFlow(QuizStudyState())
    val state: StateFlow<QuizStudyState> = _state.asStateFlow()

    private val startTimeMap = mutableMapOf<String, Long>()

    init {
        loadQuizzesForHive()
    }

    fun setInitialQuizPairs(pairs: List<Pair<Quiz, List<QuizQuestion>>>) {
        if (pairs.isEmpty()) return
        _state.update {
            it.copy(
                isLoading = false,
                quizPairs = pairs,
                error = null
            )
        }
    }

    fun startQuestionTimer(questionId: String) {
        startTimeMap[questionId] = System.currentTimeMillis()
    }

    fun submitResults(results: Map<String, String>) {
        viewModelScope.launch {
            _state.update { it.copy(isSubmitting = true) }

            // Group questions by conceptId so we can perform one aggregated
            // Bayesian update per concept rather than N compounding updates.
            val quizIdToConceptId = state.value.quizPairs
                .associate { (quiz, _) -> quiz.id to quiz.conceptId }

            // Build QuizQuestionResult list per conceptId
            val resultsByConceptId = mutableMapOf<String, MutableList<QuizQuestionResult>>()

            state.value.quizPairs.flatMap { it.second }.forEach { question ->
                val selected = results[question.id] ?: return@forEach
                val isCorrect = isAnswerCorrect(selected, question.correctAnswer)
                val duration = System.currentTimeMillis() - (startTimeMap[question.id] ?: System.currentTimeMillis())
                val conceptId = quizIdToConceptId[question.quizId] ?: return@forEach

                resultsByConceptId
                    .getOrPut(conceptId) { mutableListOf() }
                    .add(QuizQuestionResult(
                        questionId = question.id,
                        wasCorrect = isCorrect,
                        responseTimeMs = duration
                    ))
            }

            // One submitMultiple call per concept = one calibrated Bayesian update
            resultsByConceptId.forEach { (conceptId, conceptResults) ->
                submitQuizResultUseCase.submitMultiple(
                    conceptId = conceptId,
                    results = conceptResults
                )
            }

            _state.update { it.copy(isSubmitting = false) }
        }
    }

    private fun isAnswerCorrect(selected: String, correctAnswerRaw: String): Boolean {
        val correct = correctAnswerRaw.trim().uppercase()
        return selected.uppercase() == correct ||
                (selected.uppercase() == "A" && correct == "TRUE") ||
                (selected.uppercase() == "B" && correct == "FALSE")
    }

    fun loadQuizzesForHive() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }

            val conceptsResult = if (isAllHives) {
                try { Result.success(conceptRepository.getAllConcepts()) }
                catch (e: Exception) { Result.failure(e) }
            } else {
                getConceptsByHiveUseCase(hiveId)
            }

            conceptsResult.fold(
                onSuccess = { concepts ->
                    val quizPairs = mutableListOf<Pair<Quiz, List<QuizQuestion>>>()

                    concepts.forEach { concept ->
                        val quizzes = quizRepository.getQuizzesForConcept(concept.id)
                        val latest = quizzes.maxByOrNull { it.createdAt } ?: return@forEach
                        val pair = quizRepository.getQuizWithQuestions(latest.id)
                        if (pair != null && pair.second.isNotEmpty()) {
                            quizPairs.add(pair)
                        }
                    }

                    _state.update {
                        it.copy(
                            isLoading = false,
                            quizPairs = quizPairs.sortedByDescending { pair -> pair.first.createdAt },
                            error = null
                        )
                    }
                },
                onFailure = { error ->
                    _state.update {
                        it.copy(
                            isLoading = false,
                            error = error.message ?: "Failed to load quizzes"
                        )
                    }
                }
            )
        }
    }
}

data class QuizStudyState(
    val isLoading: Boolean = true,
    val isSubmitting: Boolean = false,
    val quizPairs: List<Pair<Quiz, List<QuizQuestion>>> = emptyList(),
    val error: String? = null
)