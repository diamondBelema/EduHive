package com.dibe.eduhive.di

import android.content.Context
import androidx.room.Room
import com.dibe.eduhive.data.local.dao.*
import com.dibe.eduhive.data.local.database.EduHiveDatabase
import com.dibe.eduhive.data.repository.*
import com.dibe.eduhive.data.source.*
import com.dibe.eduhive.data.source.ai.AIDataSource
import com.dibe.eduhive.data.source.file.FileDataSource
import com.dibe.eduhive.data.source.local.ConceptLocalDataSource
import com.dibe.eduhive.data.source.local.FlashcardLocalDataSource
import com.dibe.eduhive.data.source.local.HiveLocalDataSource
import com.dibe.eduhive.data.source.local.MaterialLocalDataSource
import com.dibe.eduhive.data.source.local.QuizLocalDataSource
import com.dibe.eduhive.data.source.local.ReviewEventLocalDataSource
import com.dibe.eduhive.domain.engine.BayesianConfidenceStrategy
import com.dibe.eduhive.domain.engine.BayesianConfidenceStrategyV2
import com.dibe.eduhive.domain.engine.LearningEngine
import com.dibe.eduhive.domain.repository.*
import com.dibe.eduhive.domain.usecase.concept.CreateConceptUseCase
import com.dibe.eduhive.domain.usecase.concept.GetConceptDetailsUseCase
import com.dibe.eduhive.domain.usecase.concept.GetConceptsByHiveUseCase
import com.dibe.eduhive.domain.usecase.dashboard.GetDashboardOverviewUseCase
import com.dibe.eduhive.domain.usecase.flashcard.GetFlashcardsForConceptUseCase
import com.dibe.eduhive.domain.usecase.hive.CreateHiveUseCase
import com.dibe.eduhive.domain.usecase.hive.SelectHiveUseCase
import com.dibe.eduhive.domain.usecase.material.AddMaterialUseCase
import com.dibe.eduhive.domain.usecase.material.GetMaterialsForHiveUseCase
import com.dibe.eduhive.domain.usecase.material.ProcessMaterialUseCase
import com.dibe.eduhive.domain.usecase.progress.GetWeakConceptsUseCase
import com.dibe.eduhive.domain.usecase.quiz.GenerateQuizUseCase
import com.dibe.eduhive.domain.usecase.quiz.GetQuizForConceptUseCase
import com.dibe.eduhive.domain.usecase.review.ReviewFlashcardUseCase
import com.dibe.eduhive.domain.usecase.review.SubmitQuizResultUseCase
import com.dibe.eduhive.domain.usecase.study.GetNextReviewItemsUseCase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Inject
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DataModule {

    // ========== DATABASE ==========

    @Provides
    @Singleton
    fun provideDatabase(
        @ApplicationContext context: Context
    ): EduHiveDatabase {
        return Room.databaseBuilder(
            context.applicationContext,
            EduHiveDatabase::class.java,
            "eduhive_database"
        ).build()
    }

    // ========== DAOs ==========

    @Provides
    @Singleton
    fun provideHiveDao(database: EduHiveDatabase) = database.hiveDao()

    @Provides
    @Singleton
    fun provideMaterialDao(database: EduHiveDatabase) = database.materialDao()

    @Provides
    @Singleton
    fun provideConceptDao(database: EduHiveDatabase) = database.conceptDao()

    @Provides
    @Singleton
    fun provideFlashcardDao(database: EduHiveDatabase) = database.flashcardDao()

    @Provides
    @Singleton
    fun provideQuizDao(database: EduHiveDatabase) = database.quizDao()

    @Provides
    @Singleton
    fun provideReviewDao(database: EduHiveDatabase) = database.reviewDao()

    // ========== DATA SOURCES ==========

    @Provides
    @Singleton
    fun provideHiveLocalDataSource(
        hiveDao: HiveDao
    ): HiveLocalDataSource = HiveLocalDataSource(hiveDao)

    @Provides
    @Singleton
    fun provideMaterialLocalDataSource(
        materialDao: MaterialDao
    ): MaterialLocalDataSource = MaterialLocalDataSource(materialDao)

    @Provides
    @Singleton
    fun provideConceptLocalDataSource(
        conceptDao: ConceptDao
    ): ConceptLocalDataSource = ConceptLocalDataSource(conceptDao)

    @Provides
    @Singleton
    fun provideFlashcardLocalDataSource(
        flashcardDao: FlashcardDao
    ): FlashcardLocalDataSource = FlashcardLocalDataSource(flashcardDao)

    @Provides
    @Singleton
    fun provideQuizLocalDataSource(
        quizDao: QuizDao
    ): QuizLocalDataSource = QuizLocalDataSource(quizDao)

    @Provides
    @Singleton
    fun provideReviewEventLocalDataSource(
        reviewDao: ReviewDao
    ): ReviewEventLocalDataSource = ReviewEventLocalDataSource(reviewDao)

    // ========== FILE DATA SOURCE ==========

    @Provides
    @Singleton
    fun provideFileDataSource(
        @ApplicationContext context: Context
    ): FileDataSource = FileDataSource(context)

    // ========== AI ==========

    @Provides
    @Singleton
    fun provideAIDataSource(
        modelManager: AIDataSource
    ): AIDataSource {
        // You'll set the modelId after downloading the model
        // For now, we use a placeholder
        return AIDataSource(modelId = "qwen-0.5b")
    }

    // ========== LEARNING ENGINE ==========

    @Provides
    @Singleton
    fun provideLearningEngine(): LearningEngine {
//        val strategy = BayesianConfidenceStrategy(decayRatePerDay = 0.95)
        val strategy = BayesianConfidenceStrategyV2(decayRatePerDay = 0.95)
        return LearningEngine(strategy)
    }

    // ========== REPOSITORIES ==========

    @Provides
    @Singleton
    fun provideHiveRepository(
        localDataSource: HiveLocalDataSource
    ): HiveRepository = HiveRepositoryImpl(localDataSource)

    @Provides
    @Singleton
    fun provideMaterialRepository(
        localDataSource: MaterialLocalDataSource
    ): MaterialRepository = MaterialRepositoryImpl(localDataSource)

    @Provides
    @Singleton
    fun provideConceptRepository(
        localDataSource: ConceptLocalDataSource,
        aiDataSource: AIDataSource,
        learningEngine: LearningEngine
    ): ConceptRepository = ConceptRepositoryImpl(
        localDataSource,
        aiDataSource,
        learningEngine
    )

    @Provides
    @Singleton
    fun provideFlashcardRepository(
        localDataSource: FlashcardLocalDataSource,
        aiDataSource: AIDataSource
    ): FlashcardRepository = FlashcardRepositoryImpl(
        localDataSource,
        aiDataSource
    )

    @Provides
    @Singleton
    fun provideQuizRepository(
        localDataSource: QuizLocalDataSource,
        aiDataSource: AIDataSource
    ): QuizRepository = QuizRepositoryImpl(
        localDataSource,
        aiDataSource
    )

    @Provides
    @Singleton
    fun provideReviewEventRepository(
        localDataSource: ReviewEventLocalDataSource
    ): ReviewEventRepository = ReviewEventRepositoryImpl(localDataSource)

//    ============= Use Cases ==============

    @Provides
    @Singleton
    fun provideCreateConceptUseCase(
        conceptRepository: ConceptRepository
    ): CreateConceptUseCase = CreateConceptUseCase(conceptRepository)

    @Provides
    @Singleton
    fun provideGetConceptDetailsUseCase(
        conceptRepository: ConceptRepository,
        flashcardRepository: FlashcardRepository
    ): GetConceptDetailsUseCase = GetConceptDetailsUseCase(conceptRepository, flashcardRepository)

    @Provides
    @Singleton
    fun provideGetConceptUseCase(
        conceptRepository: ConceptRepository
    ): GetConceptsByHiveUseCase = GetConceptsByHiveUseCase(conceptRepository)

    @Provides
    @Singleton
    fun provideGetDashboardOverviewUseCase (
        conceptRepository: ConceptRepository,
        flashcardRepository: FlashcardRepository,
        materialRepository: MaterialRepository,
        reviewEventRepository: ReviewEventRepository
    ): GetDashboardOverviewUseCase = GetDashboardOverviewUseCase(
        conceptRepository,
        flashcardRepository,
        materialRepository,
        reviewEventRepository
    )

    @Provides
    @Singleton
    fun provideGetFlashcardsForConceptUseCase (
        flashcardRepository: FlashcardRepository
    ): GetFlashcardsForConceptUseCase = GetFlashcardsForConceptUseCase(flashcardRepository)

    @Provides
    @Singleton
    fun provideCreateHiveUseCase (
        hiveRepository: HiveRepository
    ): CreateHiveUseCase = CreateHiveUseCase(hiveRepository)

    @Provides
    @Singleton
    fun provideGetHivesUseCase (
        hiveRepository: HiveRepository
    ): SelectHiveUseCase = SelectHiveUseCase(hiveRepository)

    @Provides
    @Singleton
    fun provideSelectHiveUseCase (
        hiveRepository: HiveRepository
    ): SelectHiveUseCase = SelectHiveUseCase(hiveRepository)

    @Provides
    @Singleton
    fun provideAddMaterialUseCase (
        materialRepository: MaterialRepository,
        fileDataSource: FileDataSource,
        conceptRepository: ConceptRepositoryImpl,
        flashcardRepository: FlashcardRepositoryImpl
    ): AddMaterialUseCase = AddMaterialUseCase(
        materialRepository,
        fileDataSource,
        conceptRepository,
        flashcardRepository
    )

    @Provides
    @Singleton
    fun provideGetMaterialsForHiveUseCase (
        materialRepository: MaterialRepository
    ): GetMaterialsForHiveUseCase = GetMaterialsForHiveUseCase(materialRepository)

    @Provides
    @Singleton
    fun provideProcessMaterialUseCase (
        materialRepository: MaterialRepository,
        fileDataSource: FileDataSource,
        conceptRepository: ConceptRepositoryImpl,
        flashcardRepository: FlashcardRepositoryImpl
    ): ProcessMaterialUseCase = ProcessMaterialUseCase(
        materialRepository,
        fileDataSource,
        conceptRepository,
        flashcardRepository
    )

    @Provides
    @Singleton
    fun provideGetWeakConceptsUseCase (
        conceptRepository: ConceptRepository
    ): GetWeakConceptsUseCase = GetWeakConceptsUseCase(conceptRepository)

    @Provides
    @Singleton
    fun provideGenerateQuizUseCase (
        quizRepository: QuizRepositoryImpl,
        conceptRepository: ConceptRepository
    ): GenerateQuizUseCase = GenerateQuizUseCase(quizRepository, conceptRepository)

    @Provides
    @Singleton
    fun provideGetQuizForConceptUseCase (
        quizRepository: QuizRepositoryImpl,
        conceptRepository: ConceptRepository
    ): GetQuizForConceptUseCase = GetQuizForConceptUseCase(quizRepository)

    @Provides
    @Singleton
    fun provideGetReviewFlashCardUseCase (
        flashcardRepository: FlashcardRepository,
        conceptRepository: ConceptRepository,
        reviewEventRepository: ReviewEventRepository
    ) : ReviewFlashcardUseCase = ReviewFlashcardUseCase(
        flashcardRepository,
        conceptRepository,
        reviewEventRepository
    )

    @Provides
    @Singleton
    fun provideSubmitQuizResultUseCase (
        conceptRepository: ConceptRepository,
        reviewEventRepository: ReviewEventRepository
    ) : SubmitQuizResultUseCase = SubmitQuizResultUseCase(
        conceptRepository,
        reviewEventRepository
    )

    @Provides
    @Singleton
    fun provideGetNextReviewItemsUseCase (
        flashcardRepository: FlashcardRepository
    ) : GetNextReviewItemsUseCase = GetNextReviewItemsUseCase(flashcardRepository)

}